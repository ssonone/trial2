---
title: "전문가 평가"
excerpt: "준비중입니다."

categories:
  - Categories3
tags:
  - [tag1, tag2]

permalink: /categories3/post-name-here-3/

toc: true
toc_sticky: true

date: 2024-06-03
last_modified_at: 2024-06-11
---

## 전문가 평가 사례

- 선정된 독특한 기술 2-3개에 대한 전문가 평가가 반드시 필요
    - 서술형으로 요약하되, 중요한 내용은 일부 표로 제시.
- (참고, 박스처리, 0.5p 이내) 전문가 선정 기준, 설문 및 인터뷰 질문 예시